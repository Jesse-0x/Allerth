<template>
<!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
<PageHeader></PageHeader>
  <h1>Register a account</h1>
  <!--using tailwind to write css-->
  <div>
    <label for="firstname">First name</label>
    <input type="text" name="firstname" id="firstname" placeholder="First name">
  </div>
  <div>
    <label for="lastname">Last name</label>
    <input type="text" name="lastname" id="lastname" placeholder="Last name">
  </div>
    <div>
      <label for="username">Username</label>
      <input type="text" name="username" id="username">
    </div>
    <div>
      <label for="password">Password</label>
      <input type="password" name="password" id="password">
    </div>
    <div>
      <label for="password2">Confirm Password</label>
      <input type="password" name="password2" id="password2">
    </div>
    <div>
      <label for="email">Email</label>
      <input type="email" name="email" id="email">
    </div>
    <div>
      <button type="submit" @click="register()">Register</button>
    </div>
<!--    <script src="static/js/register.js"></script>-->
  <PageFooter></PageFooter>

</template>

<script>
import PageHeader from "@/components/Header";
import PageFooter from "@/components/Footer";
import axios from "axios";

export default {
  name: "RegistrationPage",
  components: {PageHeader, PageFooter},
  methods:{register}
}

function register() {
  const first_name = document.getElementById("firstname").value;
  const last_name = document.getElementById("lastname").value;
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const password2 = document.getElementById("password2").value;
  const email = document.getElementById("email").value;

  if (password !== password2) {
    alert("Passwords do not match");
    return;
  }

  if (username === "" || password === "" || email === "" || first_name === "" || last_name === "") {
    alert("Please fill out username, password, email, first name, and last name");
    return;
  }

  if (/^[a-zA-Z0-9]+$/.test(username) === false) {
    alert("Username must only contain letters and numbers");
    return;
  }
  if (/^[a-zA-Z0-9]+$/.test(password) === false) {
    alert("Password must only contain letters and numbers");
    return;
  }
  if (/^[a-zA-Z0-9]+$/.test(first_name) === false) {
    alert("First name must only contain letters and numbers");
    return;
  }
  if (/^[a-zA-Z0-9]+$/.test(last_name) === false) {
    alert("Last name must only contain letters and numbers");
    return;
  }
  if (/^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(email) === false) {
    alert("Invalid email");
    return;
  }


  var data = {
    "firstname": first_name,
    "lastname": last_name,
    "username": username,
    "password": password,
    "email": email
  };
  axios.post("/api/register", data)
    .then(function (response) {
      console.log(response);
      if (response.code === 200) {
        alert("Successfully registered");
        window.location.href = "/#/login";
      } else {
        alert(data.message);
      }
    })
    .catch(function (error) {
      console.log(error);
    });
}
</script>

<style scoped>

</style>