<template>
  <div class="snap-mandatory top-8 snap-x rounded-2xl overflow-auto relative w-full flex gap-20 pb-14
  ">
<!--  bg-green-100/50">-->
    <div class="snap-center shrink-0">
      <div class="shrink-0 w-4 sm:w-48"></div>
    </div>

    <div class="snap_top bg-gradient-to-br from-[#d4fc79] to-[#96e6a1] "></div>
    <div class="snap_top bg-gradient-to-br from-[#84fab0] to-[#8fd3f4]"></div>
    <div class="snap_top bg-gradient-to-br from-[#89f7fe] to-[#75c3ff]"></div>
    <div class="snap_top bg-gradient-to-br from-[#8ec5fc] to-[#c3cdfc]"></div>
    <div class="snap_top bg-gradient-to-br from-[#b3c9ff] to-[#f59a9d]"></div>
    <div class="snap_top bg-gradient-to-br from-[#faa7aa] to-[#fac1a7]"></div>
    <div class="snap_top bg-gradient-to-br from-[#facfbb] to-[#def7b5]"></div>
    <div class="snap_top bg-gradient-to-br from-[#d9f7a8] to-[#a8f7c2]"></div>
    <div class="snap_top bg-gradient-to-br from-[#79fca2] to-[#79fcdb] "></div>


    <!--    e0c3fc→#8ec5fc-->
    <div class="snap-center shrink-0">
      <div class="shrink-0 w-4 sm:w-48"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "IntroSnap"
}
</script>

<style scoped>

</style>