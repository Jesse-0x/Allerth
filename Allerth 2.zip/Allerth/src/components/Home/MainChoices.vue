<template>
  <div class="flex mt-7 w-full h-20">
    <div class="main_snap_box from-[#ffdeab] to-[#f0898c] ">
      <span class="main_snap_box_title">New Arrivals of App & API</span>
    </div>
    <div class="main_snap_box from-[#ffefa8] to-[#fca272] ">
      <span class="main_snap_box_title">Fresh Requests of new ideas</span>
    </div>
    <div class="main_snap_box from-[#5EFCE8] to-[#9591ff] ">
      <span class="main_snap_box_title">Editors Choices & Suggestions</span>
    </div>
    <div class="main_snap_box from-[#9cffc0] to-[#6be393] ">
      <span class="main_snap_box_title">New Updates of App & API</span>
    </div>
  </div>
</template>

<script>
export default {
  name: "MainChoices"
}
</script>

<style scoped>

</style>